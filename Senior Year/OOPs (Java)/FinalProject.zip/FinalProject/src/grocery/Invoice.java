package grocery;

public class Invoice {

}
